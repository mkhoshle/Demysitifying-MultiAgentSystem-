# Setting Up Granola MCP

Granola MCP lets Claude access your meeting transcripts and notes from Granola.

## How to Connect

Run this in your terminal:

```
claude mcp add --transport http granola https://mcp.granola.ai/mcp
```

Claude Code will open a browser window for you to authorize with your Granola account. Follow the prompts to grant access.

## Verify It's Working

In Claude Code, try:

```
List my recent Granola meetings
```

If Claude can list your meetings, the connection is working.

## What This Enables

With Granola MCP connected, the /customer-call and /meeting-summary skills can:
- Pull meeting transcripts directly from Granola
- Search for meetings by title or date

## Note on Transcript Access

The `get_meeting_transcript` endpoint requires a paid Granola tier. Use `get_meetings` instead, which returns transcript content in the `private_notes` field and works on all tiers.

Without Granola, you can paste transcripts directly or point skills at transcript files in the repo.
