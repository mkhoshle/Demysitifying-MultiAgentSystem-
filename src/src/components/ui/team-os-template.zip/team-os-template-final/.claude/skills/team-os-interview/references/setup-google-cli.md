# Setting Up Google Workspace CLI (gws)

The Google Workspace CLI (`gws`) lets Claude access Google Drive, Docs, Calendar, Gmail, and Sheets from the terminal.

## Install

```
brew install googleworkspace/tap/gws
```

Or see https://github.com/googleworkspace/cli for other install methods.

## Authenticate

```
gws auth login
```

This opens a browser window for Google OAuth. Sign in with your work Google account.

## Verify It's Working

```
gws calendar +agenda
```

You should see your upcoming calendar events.

## What This Enables

With `gws` installed and authenticated, the team-os-interview skill can:
- Pull your recurring meetings from Google Calendar to identify meeting types
- The /import-doc skill can pull Google Docs into the repo as markdown

## Useful Commands

```
# List upcoming events across all calendars
gws calendar +agenda

# List Google Drive files
gws drive files list --params '{"pageSize": 10}'

# Export a Google Doc as text
gws docs documents get --params '{"documentId": "DOC_ID"}' | # extract body
```

Without it, you'll describe your meetings manually (which is fine).

## Alternative: Export Calendar as .ics (no CLI needed)

If you don't want to install `gws`, you can export your Google Calendar directly:

1. Go to https://calendar.google.com/calendar
2. In the left sidebar under "My calendars", hover over your work calendar
3. Click the three dots, then "Settings and sharing"
4. Scroll down and click "Export calendar"
5. Unzip the downloaded file
6. Drop the .ics file into your Team OS repo

The /team-os-interview skill can parse the .ics file to find your recurring meetings automatically.
