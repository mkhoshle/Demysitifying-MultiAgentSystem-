# CLAUDE.md Patterns

How to write good CLAUDE.md files at every level of the repo. Based on Hannah Stulberg's Team OS framework.

## Root CLAUDE.md

The root CLAUDE.md is loaded on every query. Keep it focused on routing and identity.

### Required Sections

**Team roster:**
```markdown
## Team

| Function | Team Member | GitHub | Slack ID |
|----------|-------------|--------|----------|
| PM | Jane Smith | `janesmith` | `U01ABC123` |
| Engineering | John Doe | `johndoe` | `U02DEF456` |
```

**Slack channels:**
```markdown
## Slack Channels

| Channel | ID | Visibility | Purpose |
|---------|-----|------------|---------|
| #engineering | `C01ABC` | Private | Engineering discussions |
| #product | `C02DEF` | Private | PRD reviews, roadmap |
```

**Doc index:**
```markdown
## Doc Index

| Area | Path | Description |
|------|------|-------------|
| Product | `product-development/product/CLAUDE.md` | PRDs, strategy, customers |
| Engineering | `product-development/engineering/CLAUDE.md` | Plans, RFCs, bugs |
```

### Optional Sections

- DM Groups (small named groups for coordination)
- Terminology (product-specific terms)
- Integrations (connected tools and accounts)

### Budget

Keep root CLAUDE.md under 200 lines. It's loaded on every query, so every line costs context.

## Folder-level CLAUDE.md

Loaded when Claude descends into a folder. Scoped to what's specific to this folder.

### Pattern

```markdown
# [Folder Name]

[One sentence describing what lives here.]

## Doc Index

| Path | Description |
|------|-------------|
| `subfolder-a/` | What subfolder A contains |
| `subfolder-b/` | What subfolder B contains |
| `important-file.md` | What this specific file is |
```

### What Belongs

- Doc index (pointers to files and subfolders)
- One-paragraph purpose of the folder
- Cross-references to related folders
- Folder-specific naming conventions

### What Does NOT Belong

- Long specs (put in their own files)
- Meeting notes (use the meetings folder)
- Status updates or changelogs
- Anything you wouldn't want loaded on every query to this folder
- Content Claude can figure out by reading the actual files

### Budget

Keep folder CLAUDE.md files under 50 lines. They are indexes, not documentation.

## Customer Account CLAUDE.md

For B2B teams with named accounts:

```markdown
# [Customer Name]

**Segment:** [Enterprise/Growth]

## Key Contacts

| Name | Role |
|------|------|
| [Name] | [Title] |

## Account Resources

| Resource | Location |
|----------|----------|
| Account context | [account-context.md](account-context.md) |
| Call summaries | [calls/summaries/](calls/summaries/) |
| Call transcripts | [calls/transcripts/](calls/transcripts/) |
```

## The 80% Rule

Put something in a CLAUDE.md if you need it on 80% of sessions in that folder. If you only need it occasionally, put it in its own file and let the doc index point to it.
