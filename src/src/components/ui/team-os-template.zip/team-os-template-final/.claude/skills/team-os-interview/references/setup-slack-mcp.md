# Setting Up Slack MCP

Slack MCP lets Claude read channels, search messages, send messages, and manage canvases in your Slack workspace.

## How to Connect

Run this in your terminal:

```
claude mcp add --transport http slack https://mcp.slack.com/mcp
```

Claude Code will open a browser window for you to authorize with your Slack workspace. Follow the prompts to grant access.

## Verify It's Working

In Claude Code, try:

```
Search Slack for "hello"
```

If Claude can search your Slack messages, the connection is working.

## What This Enables

With Slack MCP connected, the team-os-interview skill can:
- Pull your team's Slack channels and their IDs automatically
- Discover team members from a channel you specify
- Look up Slack handles for the team roster

Without it, you'll enter this information manually (which is fine, just slower).

## Troubleshooting

- If the auth window doesn't open, try restarting Claude Code and running the command again
- Make sure you're authorizing with the correct Slack workspace (your work workspace)
- You may need admin approval if your workspace restricts third-party integrations
