---
name: team-os-interview
description: Set up your Team OS from scratch. Scaffolds your folder structure, creates CLAUDE.md indexes, and populates your team roster. Use when the user says "set up my team os," "team os interview," "scaffold my repo," or wants to create a Team OS for their team.
---

# /team-os-interview

Set up your Team OS from scratch. This skill walks you through discovery, proposes a folder structure, builds it, and optionally enriches it with your team roster and Slack channels.

Before starting, read these reference files in this skill's folder:
- `references/example-structure.md` for the target folder structure
- `references/claude-md-patterns.md` for how to write CLAUDE.md files at every level

## State Management

This skill collects a lot of information. To survive context compaction, save state to disk after every major step.

- Create a `.team-os-setup/` directory at the start
- After each phase, write findings to `.team-os-setup/state.md`
- If the session compacts or restarts, read `.team-os-setup/state.md` to restore context
- At the end, clean up `.team-os-setup/` (or leave it if the user wants to reference it)

## Phase 0: Pre-flight

Check what tools are available. Run these checks silently (no need to ask permission):

1. **Slack MCP:** Try calling any Slack MCP tool (like searching channels). If it works, note "Slack MCP: connected" in state.
2. **GitHub CLI:** Run `gh --version`. If it works, note "GitHub CLI: installed". Run `gh auth status` to check auth.
3. **Google Workspace CLI:** Run `gws --version`. If it works, note "gws CLI: installed".
4. **Granola MCP:** Try calling `mcp__granola__list_meetings`. If it works, note "Granola MCP: connected".

Write results to `.team-os-setup/state.md`:

```markdown
# Team OS Setup State

## Pre-flight Results
- Slack MCP: [connected / not available]
- GitHub CLI: [installed and authed / installed but not authed / not installed]
- Google Workspace CLI (gws): [installed / not installed]
- Granola MCP: [connected / not available]
```

Tell the user what's connected and what's not. For anything missing, mention the setup guide:
"I noticed [tool] isn't set up yet. There's a setup guide at `.claude/skills/team-os-interview/references/setup-[tool].md` if you want to connect it. It's not required to continue."

Ask: "Want to set up any of these now, or continue without them?"

If they want to set something up, walk them through it using the reference docs. If not, continue.

## Phase 1: Discovery

This phase is conversational. Do NOT use AskUserQuestion for most of these. Just number the questions and let people answer naturally. Save each answer to `.team-os-setup/state.md` as you go.

### Core Questions

1. "What's your team or company name? And what product does your team work on?"

2. "What functions are on your team? For example: product management, engineering, design, analytics, data engineering, operations, marketing, sales, customer success. List whatever applies."

3. "How does your team work with customers? Do you have named accounts you track individually (like enterprise B2B), or is it more self-serve/B2C where you work with aggregate data?"

4. If B2B: "Name a few key customer accounts to seed your repo with (2-3 is fine)."

5. **Meetings (offer multiple ways to provide this):**
   - If `gws` is available: "I can pull your recurring meetings from Google Calendar. Want me to check?"
     - If yes: Run `gws calendar +agenda` or `gws calendar events list primary --params '{"timeMin":"NOW","maxResults":50}'` to find recurring events. Propose the meeting types you see.
   - Offer .ics export: "You can also export your calendar as an .ics file and drop it in this repo. To do that:
     1. Go to https://calendar.google.com/calendar
     2. In the left sidebar under 'My calendars', hover over your work calendar, click the three dots, then 'Settings and sharing'
     3. Scroll down and click 'Export calendar'
     4. Unzip the downloaded file and drop the .ics file anywhere in this repo
     Then tell me the file path and I'll parse it for recurring meetings."
   - If they parse an .ics file: Read the file, find all VEVENT entries with RRULE (recurring events), extract the SUMMARY field. Group by frequency (WEEKLY, DAILY, MONTHLY). Propose which ones look like team meetings vs personal events.
   - Or just ask directly: "What recurring meetings does your team have? For example: sprint retro, sprint planning, daily standup, weekly sync, design review, all-hands. List whatever you have."

6. "Anything else I should know about how your team works? Any tools, processes, or quirks that would affect the structure? Feel free to share as much or as little as you want."

After each answer, append to `.team-os-setup/state.md` under a `## Discovery` section. Include the raw answers so nothing is lost.

## Phase 2: Propose and Build

Read `.team-os-setup/state.md` to restore context if needed.

### Step 1: Generate the folder proposal

Read `references/example-structure.md` for the target structure. Adapt it based on what you learned:

- Always create `product-development/` as the wrapper for function-specific folders
- Always create `team/` at the root with `onboarding/`
- Only create folders for functions the team actually has
- Only create `customers/accounts/` if they're B2B with named accounts
- Create meeting subfolders for the types they listed
- All folder names use kebab-case

### Step 2: Show the proposal

Present the folder tree clearly. Explain briefly why each top-level folder exists. Then ask: "Does this look right? Anything to add, remove, or rename?"

Let them adjust. Once confirmed, proceed.

### Step 3: Build

Create all folders. Write CLAUDE.md files at every level following the patterns in `references/claude-md-patterns.md`.

**Every file you create must have YAML frontmatter with an `owner` field.** This is a best practice the workshop teaches and our GitHub Action enforces. Assign the owner based on which team member owns that function. If the roster isn't filled yet, use the team or company name as a placeholder.

Example:
```markdown
---
owner: priyasharma
---

# Engineering
...
```

For CLAUDE.md files specifically, the owner is whoever owns that area (the PM for product/, the eng lead for engineering/, etc.). Root CLAUDE.md owner is whoever runs the Team OS (usually the PM or team lead).

**Root CLAUDE.md** must have:
- Doc Index table pointing to every major folder's CLAUDE.md
- Placeholder sections for Team roster and Slack Channels (filled in Phase 3)

**product-development/CLAUDE.md** must have:
- Doc Index routing to each function folder

**Every folder CLAUDE.md** must have:
- One sentence describing what lives there
- Doc Index table listing subfolders and key files

**Customer account CLAUDE.md** (if B2B):
- Key contacts table (placeholder)
- Account resources table (links to calls/summaries, calls/transcripts, account-context.md)

After building, save a build report to `.team-os-setup/state.md` listing every file created.

Tell the user what was built: folder count, CLAUDE.md count, and the top-level structure.

## Phase 3: Enrich (optional, each part skippable)

After Phase 2, the repo is functional. Phase 3 adds team identity and connections. Each sub-step is independently skippable.

"Your Team OS structure is built. All the folder indexes are in place. Now I can help you add your team roster and Slack channels. These make natural-language team coordination possible (like 'message the backend crew about this bug'). Each of these is optional and you can always come back to it."

### 3a: Team Roster

"Want to add your team roster now?"

If yes, offer approaches based on what's available:

**If Slack MCP is connected (recommended):**
"What Slack channel has most of your team members in it?"
- Pull the member list from that channel
- Propose the roster: "I found these people in #[channel]. Here's what I'd add to the roster:"
- Show the proposed table
- Ask them to confirm, add anyone missing, and fill in roles
- For GitHub handles: "Do you know their GitHub usernames? I can try to look them up, or you can fill these in later."

**If no Slack MCP:**
"You can either:
1. List your team members here (name, role, and optionally their GitHub and Slack handles)
2. Create a CSV with columns: Function, Name, GitHub, Slack ID and paste it or give me the file path

GitHub and Slack handles are optional. You can fill them in later."

Add the Team section to root CLAUDE.md.

### 3b: Slack Channels

"Want to add your Slack channels?"

**If Slack MCP is connected:**
- Search for the team's channels
- Propose a list: "I found these channels in your workspace. Which ones should be in your Team OS?"
- Let them pick and add purposes for each
- Add channel IDs automatically from the MCP data

**If no Slack MCP:**
"List the Slack channels your team uses most. I just need the channel name and a short description of what it's for. Channel IDs are optional (you can add them later)."

Add the Slack Channels section to root CLAUDE.md.

### 3c: Deploy to GitHub

"Want to push this to GitHub so your team can clone it?"

If yes, check for GitHub CLI (from pre-flight). If not installed or authed, point to `references/setup-github-cli.md` and walk them through it.

Then:
1. Ask: "What should the repo be called?"
2. Run: `gh repo create [name] --private --source=. --push`
3. Report the repo URL

## Wrap-up

"Your Team OS is ready. Here's what to try next:

1. Explore the Forge Labs example repo to see a fully built-out Team OS with real skills in action
2. Check the skills in `.claude/skills/` to see what's available
3. Wire up hooks by copying `settings-example.json` to `.claude/settings.json`

Everything you skipped can be added later by editing root CLAUDE.md."

## Rules

- Save state to `.team-os-setup/state.md` after every major step. This is critical for surviving compaction.
- Do NOT use AskUserQuestion for open-ended questions. Just ask conversationally and let people type freely.
- Use AskUserQuestion only for small fixed-choice questions (like "want to set this up now or skip?").
- Never create sample/stub content files. Only create CLAUDE.md indexes and folder structure.
- All folder names use kebab-case.
- Keep each CLAUDE.md under 50 lines. These are indexes, not documentation.
- Do not modify anything in `.claude/` (skills, hooks, rules are already set up).
- Read the reference files in this skill's folder before generating any CLAUDE.md content.
