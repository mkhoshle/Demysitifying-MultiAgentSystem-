# Setting Up GitHub CLI

The GitHub CLI (`gh`) lets Claude create repos, open PRs, and manage GitHub from the terminal.

## Install

**Mac:**
```
brew install gh
```

**Windows:**
```
winget install GitHub.cli
```

**Linux:**
See https://cli.github.com for your distribution.

## Authenticate

```
gh auth login
```

Choose:
1. GitHub.com
2. HTTPS
3. Login with a web browser

It will give you a code to enter at github.com/login/device.

## Verify It's Working

```
gh auth status
```

You should see your username and the scopes granted.

## What This Enables

With `gh` installed and authenticated, the team-os-interview skill can:
- Create a GitHub repo for your Team OS
- Push your scaffolded repo so your team can clone it
- Open PRs and assign reviewers (used by the /commit-push-pr-slack skill)

Without it, you can still build your Team OS locally. You'll just need to create the GitHub repo manually later.
