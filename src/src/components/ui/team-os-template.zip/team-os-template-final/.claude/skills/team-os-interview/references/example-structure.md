# Example Team OS Structure

This is the structure from Hannah Stulberg's open source example repo (github.com/in-the-weeds-hannah-stulberg/team-os-example-repo). Use this as a reference for what a well-structured Team OS looks like. Adapt the structure to fit the user's team, not every team will have every folder.

## Top-level Layout

```
repo-root/
  CLAUDE.md                          # Team roster, Slack channels, doc index
  product-development/               # Wrapper for all function-specific folders
    CLAUDE.md                        # Routes to each function's CLAUDE.md
    product/                         # PM-owned: PRDs, strategy, customers, meetings
    engineering/                     # Eng-owned: plans, RFCs, bug investigations
    analytics/                       # Data-owned: metrics, queries, dashboards, experiments
    data-engineering/                # Data eng: pipeline plans and RFCs
    design/                          # Design: mostly lives in Figma, stubs here
    feature-index.yaml               # Master lookup mapping features to artifacts
  team/                              # Cross-functional: onboarding, retros
```

## Root CLAUDE.md Sections

The root CLAUDE.md is the most important file. It has four sections:

1. **Team roster** (table: Function, Name, GitHub, Linear/Jira ID, Slack ID)
2. **Slack Channels** (table: Channel, ID, Visibility, Purpose) + DM Groups
3. **Doc Index** (table: Area, File, Description) pointing to every major folder's CLAUDE.md
4. Optionally: terminology, integrations

## Folder-level CLAUDE.md Pattern

Every folder has a CLAUDE.md that serves as its index. The pattern:

```markdown
# [Folder Name]

[One sentence: what lives here.]

## Doc Index

| Path | Description |
|------|-------------|
| `subfolder/` | What this subfolder contains |
| `file.md` | What this file is |
```

Keep folder CLAUDE.md files short (under 50 lines). They are indexes, not documentation.

## Product Folder Structure

```
product/
  CLAUDE.md                    # Product context, pillars, key docs
  PRDs/                        # Product requirement documents
  strategy/                    # Roadmaps, vision, business context
    roadmaps/
    vision/
    business-context/
  customers/                   # B2B: named accounts with call data
    accounts/
      [customer-name]/
        CLAUDE.md              # Key contacts, account resources
        account-context.md     # Segment, ARR, health, goals
        calls/
          summaries/           # Structured call summaries
          transcripts/         # Raw transcripts
  competitive-research/        # Competitor intel
    competitors/
      [competitor-name]/
        CLAUDE.md
        tldr.md
        pricing.md
  launch-emails/               # Launch communications
  sales-enablement/            # Sales-facing docs
  meetings/                    # Recurring meeting summaries
    [meeting-type]/
      summaries/
      transcripts/
      docs/                    # Prep docs, agendas
  processes/                   # Operational how-tos
  workflows/                   # Automated workflow specs
```

## Engineering Folder Structure

```
engineering/
  CLAUDE.md
  plans/                       # Implementation plans by product area
    [product-area]/
  rfcs/                        # Technical design proposals by product area
    [product-area]/
  bug-investigations/          # Dated bug investigations by product area
    [product-area]/
      bug-YYYY-MM-DD-[slug]/
        investigation-plan.md
```

## Analytics Folder Structure

```
analytics/
  CLAUDE.md                    # Data sources, core metrics, dashboard links
  metrics/                     # Metric definitions by product area
    [product-area]/
  queries/                     # SQL queries by product area
    [product-area]/
  schemas/                     # Table docs by product area
    [product-area]/
  dashboards/                  # Dashboard specs by product area
    [product-area]/
  experiments/                 # A/B test results by product area
    [product-area]/
  investigations/              # Ad hoc analyses by product area
    [product-area]/
```

## Key Principles

- Every folder has a CLAUDE.md with a doc index
- All function folders live under `product-development/`
- `team/` stays at the root (cross-functional)
- Product areas repeat across functions (billing/, deployment/, etc.)
- Named customer accounts only if B2B
- Meetings organized by type (retro, standup, sprint-planning, etc.)
- File names use kebab-case
- Bug investigations use date-prefixed folders
