# Team OS Starter

Your starting point for building a Team OS with Claude Code. Download this repo, run the setup interview, and walk out with a scaffolded Team OS for your team.

## Prerequisites

- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) installed (Pro or Max subscription)

## Quick Start

1. Download and unzip this repo
2. Open it in Claude Code
3. Run `/team-os-interview`

The interview will walk you through setting up your folder structure, CLAUDE.md indexes, team roster, and Slack channels. It checks for connected tools (Slack MCP, GitHub CLI, Google Workspace CLI) and uses them to speed things up if available.

## What You Get

After running the interview, your repo will have:
- A folder structure tailored to your team's functions
- CLAUDE.md doc indexes at every level (so Claude can navigate your repo)
- A team roster with Slack handles (so Claude can resolve "message the backend crew")
- Slack channels table (so skills know where to post)

## Example Repo

Want to see what a fully built-out Team OS looks like? Check out the Forge Labs example repo with real skills, hooks, customer data, and meeting summaries. Available on the course materials page.

## Links

- [Course Materials](https://fullstackpm.com/workshop) (password: `teamosletsgo`)
- [GitHub 101 Guide](https://hannahstulberg.substack.com/p/tool-school-github-101)
